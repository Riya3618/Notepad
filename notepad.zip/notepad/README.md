# Notepad

A Pen created on CodePen.io. Original URL: [https://codepen.io/riya_jha/pen/jOxYvLB](https://codepen.io/riya_jha/pen/jOxYvLB).

